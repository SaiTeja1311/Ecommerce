ham = document.querySelector('.bar');
ham.onclick = function(){
    navbar = document.querySelector('.nav_bar');
    navbar.classList.toggle('active');
}


// button slide

function btnright(){
  var x = document.getElementById("head4");


  if(x.innerHTML === "Prince Harkhuf"){
    x.innerHTML = "Prince Rochak"
  }else if(x.innerHTML === "Prince Rochak"){
    x.innerHTML = "Prince Morjiorch"
  }else{
    x.innerHTML = "Prince Harkhuf"
  }
}

function btnleft(){
  var y = document.getElementById("head4");


  if(y.innerHTML === "Prince Harkhuf"){
    y.innerHTML = "Prince Rochak"
  }else if(y.innerHTML === "Prince Rochak"){
    y.innerHTML = "Prince Morjiorch"
  }else{
    y.innerHTML = "Prince Harkhuf"
  }
}

// end
